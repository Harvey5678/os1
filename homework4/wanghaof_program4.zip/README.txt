Using the following command on os1 to compile my code:
gcc --std=gnu99 -o line_processor main.c -lpthread

